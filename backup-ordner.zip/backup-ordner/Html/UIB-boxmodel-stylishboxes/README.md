# Boxes, boxes and more boxes

**Instructions**:
* Task 1: Align the sections with the class `info-box` side-by-side. Give the elements a box shadow.

* Task 2: Use :before and :after to add "Read this" and "End of Story" to each info-box

![reference-image](/image/reference-image.png)