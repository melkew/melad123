console.log("A 1:");

let summe = 0;
for (let x = 1; x<=20; x++){
    summe = summe +x;
}
console.log(summe);

console.log("A 2:");


let howMany = "";
for (let x = 1; x <= 5; x++){
    switch(x){
        case 1:
            console.log("There is one bottle of beer on the wall");
            continue;
            break;
        case 2:
            howMany = "two";
            break;    
        case 3:
           howMany = "three";
           break;
        case 4:
            howMany = "four";
            break;
        case 5:
            howMany = "five";
            break;
    }
    console.log(`There are ${howMany} Bottles of Beer on the wall`);
}

console.log("A 3:");


for (var i = 0; i <= 20; i++) {
    if (i % 2 === 0) {
        console.log(i + ' is even');
    } else {
        console.log(i + ' is odd');
    }
}

console.log("A 4:");

// multiplication Tables. Write a program that will iterate from 0 to 10. 
// For each iteration of the for loop, it will multiply the number by 9 and log the result (e.g. "2 * 9 = 18").
//  Bonus: Use a nested for loop to show the tables for every multiplier from 1 to 10 (100 results total).
var z = 9;
for (var i = 0; i <= 10; i++) {
    var result = z * i;
    console.log(z + ' * ' + i + ' = ' + result);
}


for (var z = 0; z <= 10; z++) {
 for (var i = 0; i <= 10; i++) {
   var result = z * i;
   console.log(z + ' * ' + i + ' = ' + result);
 }
}


console.log("A 5:");

/*Fizz Buzz Write a program which iterates the integers from 1 to 100. 
But for multiples of three print "Fizz" instead of the number and for the multiples of five print "Buzz".
For numbers which are multiples of both three and five print "FizzBuzz".*/



for(let k = 1; k<=100;k++){
    if((k%3===0 )&& (k%5===0)){
        console.log("FizzBuzz")
    }
    else if(k%5===0){
        console.log("Buzz")
    }
    else if (k%3===0){
        console.log("Fizz")
    }
    else {
        console.log(k)
    }
}

console.log("A 6:");

let summ = 0;
for(let r = 1; r<=1000;r++){
    if((r%3===0) || (r%5===0)){
        summ = summ + r;
     
}
}
console.log(summ);

console.log("A 7:");

// Write programs that produce the following outputs:
// 100 200 300 400 500 600 700 800 900 1000

// 1 2 4 8 16 32 64 128

// 0 2 4 6 8 10

// 3 6 9 12 15

// 9 8 7 6 5 4 3 2 1 0

// 1 1 1 2 2 2 3 3 3 4 4 4

// 0 1 2 3 4 0 1 2 3 4 0 1 2 3 4

console.log("bonus 1:");



// for (let c= 1; c <= 1000; c++){
//     switch(c){
//         case 100:
//             console.log(c);
            
//             break;
//         case 200:
//             console.log(c);
//             break;    
//         case 300:
//             console.log(c);
//            break;
//         case 400:
//             console.log(c);
//             break;
//         case 500:
//             console.log(c);
//             break;
//         case 600:
//             console.log(c);
//             break;
//         case 700:
//             console.log(c);
//             break;
//         case 800:
//             console.log(c);
//             break;
//         case 900:
//             console.log(c);
//             break;
//         case 1000:
//             console.log(c);
//             break;
//     }
// }

// for(l=1; l<=10;l++){
//     console.log(l*100);
// }


for (let c= 100; c <= 1000; c+=100){
    console.log(c)
}

console.log("bonus 2:");

for(let p=1; p<=128;p*=2){

        console.log(p );
    
}

console.log("bonus 3:");


for(let R=0; R<=10;R++){
    if(R%2===0){
        console.log(R);
    }
}
console.log("bonus 4:");


for(let s=3; s<=15;s=s+3){

    console.log(s);

}
console.log("bonus 5:");

for(let result=9; result>=0;result--){

    console.log(result);
    }

console.log("bonus 6:");


for(let result2 = 1 ; result2<=4 ;result2++){
    for(let i = 1 ; i<=3 ;i++){
        console.log(result2);

    }
}

console.log("bonus 7:");

for(let a = 1 ; a<=4 ;a++){
    for(let a = 1 ; a<=4 ;a++){
        console.log(a);

    }
}

console.log("A 8:");



function checkPalindrome(word) {    
    var l = word.length;
    for (var i = 0; i < l / 2; i++) {
        if (word.charAt(i) !== word.charAt(l - 1 - i)) {
            return false;
        }
    }
    return true;
}

if (checkPalindrome("melad")) {
    console.log("The word is a palindrome");
} else {
    console.log("The word is NOT a palindrome");
}


// function check(word) {
//     for (var i = 0; i < word.length / 2; i++) {
//         if (word[i] !== word.charAt(word.length - 1 - i)) {
//             return false + ' ' + word + " is NOT a palindrome" ;
//         }
//     }
//     return true + ' ' + word + " is a palindrome" ;
// }
// console.log(check("madam"));