# Basic HTML Exercises

## Exercise: Escape the characters

**Instructions**:

Use the reference chart in the following link to fix the paragraphs by replacing the following characters with their html entities: <, >, &, ", '

Reference: https://dev.w3.org/html5/html-author/charref
