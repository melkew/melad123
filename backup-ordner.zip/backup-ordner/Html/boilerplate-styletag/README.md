# You've got style!

**Instructions**: 
* Go to the HTML file. Add a style tag to the head of the document. 
* Change the color of the paragraph elements.

![mockup-image](/image/reference-image.png)