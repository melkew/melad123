# Make your fonts awesome!

**Instructions**:
* Link font awesome to your html page.
* Add a font awesome icon to the front and back of the h1 heading. 
* Center and underline the h1 heading.
* Center the element with the class `review`. Give this element text shadow and display the text as uppercase.
* Add icons to the front of each paragraph element nested in the sections with the class `info`.
* Add appropriate icons after each possible review. 
* Resize the icons on the page.

* Desktop
![alt-text](/images/reference-image-desktop.png "Reference Image Desktop")
* Mobile
![alt-text](/images/reference-image-mobile.png "Reference Image Desktop")
