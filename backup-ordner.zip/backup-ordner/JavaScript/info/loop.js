// //while loop 
// let x = 1;
// while (x<=10){
//     console.log(x);
//     x = x +1;
// }

//for loop
for (let x = 1; x<=10; x++){
    if(x%2 === 0){
    console.log(x)
        
    }
    if(x === 6){
        break;
    }
    //wird unsere schleife ausgefürt
}



//schreibe alle zahlen zwischen 1 und 10 ; 3 mal.


for(let y = 1 ; y<=10 ;y++){
    for(let i = 1 ; i<=3 ;i++){
        console.log(y);

    }
}


// Write a program to add up the numbers 1 to 20.
let summe = 0;
for (let x = 1; x<=20; x++){
    summe = summe +x;
}
console.log(summe);