console.log("----Aufgabe 1----");
// 1. Add Up. Create a function that takes a number as an argument. Add up all the numbers from 1 to the number you passed to the function. For example, 
// if the input is 4 then your function should return 10 because 1 + 2 + 3 + 4 = 10.

// Examples:

// addUp(4) ➞ 10
// addUp(13) ➞ 91
// addUp(600) ➞ 180300

const numbers = (num) => {
    let result = 0;
    for (i = 0; i <= num; i++) {
        result += i;
    }
    return result
}
console.log(numbers(4))



console.log("----Aufgabe 2----");

// 2. Cubed. Create a function that takes in three numbers and returns the sum of its cubes.

// Examples:

// sumOfCubes(1, 5, 9) ➞ 855 // Since 1^3 + 5^3 + 9^3 = 1 + 125 + 729 = 855
// sumOfCubes(2) ➞ 8
// sumOfCubes() ➞ 0

// const cubed = (sum) => {

//         for (i = 0; i <= sum.length; i++) {
//      Cubes = Math.pow.apply(num[i], 3)
//     }
//     return Cubes
// }
// console.log(cubed(1, 5, 9))


const cubed = (a, b, c) => {


    let cube1 = Math.pow(a, 3) || 0;
    let cube2 = Math.pow(b, 3) || 0;
    let cube3 = Math.pow(c, 3) || 0;
    let result = 0;
    result = cube1 + cube2 + cube3;

    console.log(result)
}
cubed(1, 5, 9)
cubed(2)
cubed()



console.log("----Aufgabe 3----");

//         3. String Check. Create a function that takes a string and a word, and then returns true or false depending on whether the word starts with the initial string.

// Examples:

// dictionary("bu", "button") ➞ true
// dictionary("tri", "triplet") ➞ true
// dictionary("beau", "pastry") ➞ false


const dictionary = (a, b) => {
    if (b.startsWith(a)) {
        return true
    }
    return false
}

console.log(dictionary("bu", "button"));
console.log(dictionary("tri", "triplet"));
console.log(dictionary("beau", "pastry"));



console.log("----Aufgabe 4----");
// 4. Less Than or Equal to Zero? Create a function that takes a number as its only argument and returns true if it's less than or equal to zero, otherwise return false.

// Examples:

// lessThanOrEqualToZero(3) ➞ false
// lessThanOrEqualToZero(0) ➞ true
// lessThanOrEqualToZero(-4) ➞ true
// lessThanOrEqualToZero(10) ➞ false


const lessThanOrEqualToZero = (a) => {
    if (a <= 0) {
        return true
    }
    return false
}
console.log(lessThanOrEqualToZero(3))
console.log(lessThanOrEqualToZero(0))
console.log(lessThanOrEqualToZero(-4))
console.log(lessThanOrEqualToZero(10))


console.log("----Aufgabe 5----");

// 5. Count Occurrences. Create a function that accepts two arguments: a string and a letter.
//  The function should count the number of occurrences of that letter in the string.

// i.e. countOccurrences("this is a string", "i") ➞ 3


let counter = (string) => {
    let count = 0;
    for (x = 0; x < string.length; x++) {
        if (string[x] === "i") {
            count += 1;
        }
    }
    return count
}
console.log(counter("this is a string"));




console.log("----Aufgabe 6----");

// 6. X To The Power of X. Create a function that takes a base number and an exponent number and returns the calculation. NB: All test inputs will be positive integers.

// Examples:

// calculateBaseToExponent(5, 5) ➞ 3125
// calculateBaseToExponent(10, 10) ➞ 10000000000
// calculateBaseToExponent(3, 3) ➞ 27

const calculateBaseToExponent = (a, b) => {
    let result = Math.pow(a, b);
    return result;
}
console.log(calculateBaseToExponent(5, 5))
console.log(calculateBaseToExponent(10, 10))
console.log(calculateBaseToExponent(3, 3))



console.log("----Aufgabe 7----");

// 7. Where's Waldo? Create a function that takes a string and returns true if Waldo is found, and false if he's not.

// Examples:

// isWaldoHere("is there wal here ?") ➞ false
// isWaldoHere("I found you Waldo!") ➞ true
// isWaldoHere("is wally here?") ➞ false
// isWaldoHere("waldo is here") ➞ true


const isWaldoHere = (string) => {
    if (string.includes("Waldo")) {
        return true
    }
    return false
}

console.log(isWaldoHere("is there wal here ?"));
console.log(isWaldoHere("I found you Waldo !"));
console.log(isWaldoHere("is wally here?"));
console.log(isWaldoHere("Waldo is here"));


console.log("----Aufgabe 8----");

// 8. Pie. Create a function that determines whether or not it's possible to split a pie fairly given these three parameters:

// Total number of slices.
// Number of recipients.
// How many slices each person gets.
// Examples:

// equalSlices(11, 5, 3) ➞ false // 5 people x 3 slices each = 15 slices > 11 slices

// equalSlices(8, 3, 2) ➞ true

// equalSlices(8, 3, 3) ➞ false

// equalSlices(24, 12, 2) ➞ true


const equalSlices = (a, b, c) => {
    if (b * c <= a) {
        return true
    }
    return false
}

console.log(equalSlices(11, 5, 3));
console.log(equalSlices(8, 3, 2));
console.log(equalSlices(8, 3, 3));
console.log(equalSlices(24, 12, 2));



console.log("----Aufgabe 9----");

// 9. XO Create a function that takes a string, checks if it has the same number of 'x's and 'o's and returns either true or false.

// Notes:

// Return a boolean value (true or false).
// The string can contain any character.
// When neither an x nor an o is in the string, return true.
// Examples:

// XO("ooxx") ➞ true
// XO("xooxx") ➞ false
// XO("ooxXm") ➞ true (case insensitive)
// XO("zpzpzpp") ➞ true (returns true if no x and o)
// XO("zzoo") ➞ false


const xo = (aString, ) => {
    let countX = 0;
    let countO = 0;
    for (i = 0; i < aString.length; i++) {
        if ((aString[i] === "x") || (aString[i] === "X")) {
            countX += 1;
        }

        if ((aString[i] === "o") || (aString[i] === "O")) {
            countO += 1;
        } else {

        }
    }
    if (countO === countX) {
        return true
    } else {
        return false
    }


}

console.log(xo("ooxx"));
console.log(xo("xooxx"));
console.log(xo("ooxXm"));
console.log(xo("zpzpzpp"));
console.log(xo("zzoo"));


console.log("----Aufgabe 10----");

// 10. isPrime? Create a function that returns true if a number is prime and false if it's not. NB: a prime number is any positive integer greater than 1, 
// which is only evenly divisible by two divisors: itself and 1. The first ten prime numbers are 2, 3, 5, 7, 11, 13, 17, 19, 23 and 29.

// Examples:

// isPrime(7) ➞ true
// isPrime(9) ➞ false
// isPrime(10) ➞ false

const isPrime = (num) => {
    for (i = 2; i < num; i++) {
        if (num % i === 0) {
            return false
        }
        if (i === num - 1) {
            return true
        }
    }
}

console.log(isPrime(7));
console.log(isPrime(9));
console.log(isPrime(10));


console.log("----Aufgabe 11----");


// 11. Validate Email. Create a function that takes a string, checks if it's a valid email address, and then accordingly returns either true or false.

// The string must contain an "@" character.
// The string must contain a "." character.
// The "@" must have at least one character in front of it.
// e.g. "john@example.com" is valid while "@example.com" is invalid.
// The "." and the "@" must be in the appropriate places.
// e.g. "john.smith@com" is invalid while "john.smith@email.com" is valid.


  const ValidateEmail =(email)=>{
 
 if((email.includes("@")) && (email.includes(".")) && (email.includes(".com"))){
     return "it is  valid"
 }

 if(email.includes("@")){
     return "it is not valid"
 }

 }

  console.log(ValidateEmail("johns.mith@email.com"))