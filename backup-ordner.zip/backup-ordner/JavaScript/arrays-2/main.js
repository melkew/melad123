console.log(" ---1--- ");

// Declare a variable named "euroCities" and assign an array to the variable e.g.
//  ["Paris", "London", "Valletta", "Prague", "Rome"]. 
//  Declare another variable and assign the second item of the array as a value.

let euroCities = ["Paris", "London", "Valletta", "Prague", "Rome"];
let otherEuroCities = euroCities[1];

console.log(euroCities);

console.log(" ---2--- ");
// Change the first item in the array to "Berlin".

var changeFirstCity = euroCities.splice(0 ,1 ,"Berlin");

console.log(euroCities);

console.log(" ---3--- ");

//Print the length of the array "euroCities".

console.log(euroCities.length);



console.log(" ---4--- ");
// Remove the last item of the array "euroCities".

console.log(euroCities.pop());
console.log(euroCities);

console.log(" ---5--- ");

// Use an array method to add "Budapest" to the euroCities array.

console.log(euroCities.push("Budapest"));
console.log(euroCities);

console.log(" ---6--- ");

// Bonus: Remove the second and third items from the euroCities array.

console.log(euroCities.splice(1,1, ));
console.log(euroCities.splice(1,1, ));
// console.log(euroCities.splice(1,2));
console.log(euroCities);


console.log(" ---7--- ");
// Create another variable named asianCities and assign an array of at least 5 cities to the variable.

var asianCities = ["Amman", "Damaskus", "Qatar" , "Swaida", "Aleppo"];


console.log(" ---8--- ");
// Bonus: Use an array method to select items 2-4 from the array of asianCities and store this in another variable.

var newAsianCities = asianCities.slice(1,4)

console.log(newAsianCities);

console.log(" ---9--- ");
// Bonus: Use a method to concat euroCities with asianCities. Store the result in a variable (eg. worldCities).

let worldCities = euroCities.concat(asianCities) ;
console.log(worldCities);

console.log(" ---10--- ");
//Reverse the order of worldCities.

console.log(worldCities.reverse())


console.log(" ---11--- ");
//Bonus: Replace the 3rd item in the array of worldCities with "Toronto".

console.log(worldCities.splice(2,1,"Toronto"));
console.log(worldCities);


console.log(" ---12--- ");

//Bonus: Remove no elements from the array of worldCities, but insert "Washington" at the 2nd position.

console.log(worldCities.splice(1,0,"Washington"));
console.log(worldCities);

console.log(" ---13--- ");

//Bonus Write a program to join all elements of the result (worldCities) into a string. 
// Example: worldCities = ["Berlin", "London", "Bangkok", "Phnom Penh"]; 
// Expected Outputs: "Berlin , London, Bangkok, Phnom Penh" "Berlin+London+Bangkok+Phnom Penh"

console.log(worldCities.join(", "));
console.log(worldCities.join("+"));

console.log(" ---Bonus--- ");
// Write a program to reverse the string: "Hello World".
let str = "Hello World"
function reverseString(str){
    let splitString = str.split("");
    let reverseArray =splitString.reverse();
    let joinArray = reverseArray.join("")
    return joinArray;
}

console.log(reverseString("Hello World"))