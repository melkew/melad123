console.log("Aufgabe 1:");

let introSentence = "Das ist ein String ";
let number = 5;
console.log(introSentence + number);

// the + in this case is conn

console.log("Aufgabe 2:");

let number1 = "1005";
let float = "10.05";
console.log(parseInt(number1));
console.log(parseFloat(float))

console.log("Aufgabe 3:");

// (condition) ? wenn condition it true : wenn condition ist false
// 12 % 2 === 0

let var1 =30;
let var2 = 939; 
let var3 = 40.9;
console.log(var1%2 ===0 ? 'even':`odd`);
console.log(var2%2 ===0 ? 'even':`odd`);
console.log(var3%2 ===0 ? 'even':`odd`);


