# Melad

## Male ein schlechtes Selbstportrait von dir: 
![Melad](./images/images1.jpeg "Melad")

## Woher kommst du?
Aus Schleswig Holstein. 

## Welche Hobbies hast du?
Musik spielen, lesen, sport machen, Programmieren.

 

## Welche Musik hörst du wenn du lange am Computer arbeitest?
60er jazz musik.

## Welche Website kannst du empfehlen?
[www.codeacademy.com](www.codeacademy.com)

Da gibts Antworten auf alle Programmier-Fragen. 

## Drücke deine Stimmung in einem Emoji aus
:space_invader:

## Erstelle eine Tabelle mit Essen, dass du magst und nicht magst

| Ich mag das | Ich mag das nicht |
| --- | --- |
| Bananen |  |
| Fleisch | Lakritze |
| Kürbissuppe | Marzipan |
