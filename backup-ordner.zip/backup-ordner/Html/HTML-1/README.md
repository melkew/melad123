# HTML Document 

**Instructions**
* Create an HTML file.
* In the file, declare the document type. 
* Create the root element of the page. 
* Nested in that root element, create a `head` and a `body` element. 
