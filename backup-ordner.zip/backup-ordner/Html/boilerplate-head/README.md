# Time to be meta

**Instructions**
* Create and HTML file. 
* In the file, declare the document type and add the root element.
* Nested in the root element, add a `head` element and a `body` element.
* In the `head` element, create a meta tag for charset and author. Add your name to the author tag. 
* Add a title in the meta tag and give your document a title. 