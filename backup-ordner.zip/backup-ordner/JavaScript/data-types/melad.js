console.log("Aufgabe 1:")

let string = "Melad12";
console.log(string);


console.log("Aufgabe 2:");

zweitebuchstabe = string [1];
// console.log(string[1]);
sechstebuhcstabe = string [5];
// console.log(string[4]);

console.log(`they are ${zweitebuchstabe} + ${sechstebuhcstabe}`)

console.log("Aufgabe 3:");

let name = "appolo18";

console.log("Aufgabe 4:");

let age = 22;

console.log("Afgabe 5:");

let year = 1997;

console.log("Aufgabe 6:");

console.log( name + "is" + age + "in" + year );

console.log("Aufagebe 7:");

let isMarried = false;
console.log(isMarried);

console.log("Aufgabe 8:");

console.log(name +"is marrid"+ isMarried);

console.log("Aufgabe 9:");

let programmingLanguage = "JavaScript" ;
let isFun = true;
 console.log(programmingLanguage + " is fun: " + isFun);

 console.log("Aufgabe 10:");

 ersterbuchstabe = programmingLanguage [0];
 fuenftebuchstabe = programmingLanguage [4];
 console.log("the first one is " + ersterbuchstabe + " and the 5th is " + fuenftebuchstabe ); 

 console.log("Aufgabe 11:");

 console.log(programmingLanguage.length);
