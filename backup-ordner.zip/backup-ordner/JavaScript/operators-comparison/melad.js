let x = 20;
let y = 30;
let z = 5; 

console.log("aufgabe 1 :");
console.log(x === y);

console.log("aufgabe 2 :");
console.log(x !== y);

console.log("aufgabe 3 :");
console.log(x > y);

console.log("aufgabe 4 :");
console.log(x < y);

console.log("aufgabe 5 :");
console.log(y > x);

console.log("aufgabe 6 :");
console.log((z*x) > (z + y));

console.log("aufgabe 7 :");
console.log((x- z) < (y/z));

// aufgabe 8:

 a = x === y; //false
 b = y === z; // false
console.log("aufgabe 8:");
 console.log(a && b);

 // aufgabe 9:

 remX= x%z;
 remY= y%z;

 console.log("aufgabe 9 :");
 //lange
 console.log(remX);
 console.log(remY);
 console.log(remX===remY);
 //kurzer
 console.log((x%z)===(y%z));
 
 console.log("aufgabe 10 :");
 console.log((z+x) > (y-z));

 zGleichX= z+x;
 yMinusZ= y-z;
 console.log(zGleichX >= yMinusZ);


