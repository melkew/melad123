// Finish these Functions

console.log("---1---")
// Write a function that finds out how many elements are in an array
const fruits = ["Banana", "Apple", "Orange"];

const fruitCounter = (someArray) => {
    return someArray.length; // edited 
}

console.log(fruitCounter(fruits)); //Should return 3 
fruits.push("Kiwi");
console.log(fruitCounter(fruits)); //Should return 4

console.log("---2---");
// Write a function that returns the second element of an array.arr
const instruments = ["Guitar", "Piano", "Drums", "Trumpet"];
const secondElement = (someArray) => {
    return someArray[1]; // edited
}

console.log(secondElement(instruments)); // Should return Piano


console.log("---3---");
// Write a function that takes a string and
// returns "Oh no" on a weekday and "Oh yes" on a weekend.
const dayChecker = (dayOfTheWeek) => {
    if ((dayOfTheWeek === "saturday") || (dayOfTheWeek === "sunday")) { // Edited
        return "Oh Yes!";
    } else {
        return "Oh No!";
    }
}

console.log(dayChecker("sunday")); // Should return "Oh Yes!"
console.log(dayChecker("monday")); // Should return "Oh No!"

console.log("---4---");
// Write a function that loops through an array and returns all indexes of numbers greater than 10
const numbers = [0, 10, 11, 200, -39, 23];
const greaterThanTen = (numArray) => {
    let allIndexes = "";
    for (let i = 0; i <= numArray.length - 1; i++) {
        if (numArray[i] > 10) {
            allIndexes = allIndexes + i + ","; //edied
        }
    }
    return allIndexes; // edited
}
console.log(greaterThanTen(numbers)); // Should return 2, 3, 5

console.log("---5---");
// Write a function that adds all numbers between 0 and 100
const adder = () => {
    let result = 0;
    for (let i = 0; i <= 100; i++) {
        result = result + i; // edited
    }
    return result; // edited
}
const additionResult = adder();
console.log(additionResult); // Should return 5050

console.log("---6---");
//Write a function that adds all even numbers between 0 and 100;
const evenAdder = () => {
    let result = 0;
    for (let i = 0; i <= 100; i++) { // Edited
        if (i % 2 === 0) { // Edited
            result += i;
        }
    }
    return result;
}

console.log(evenAdder()); // Should return 2550

console.log("---7---");
// Write a function that checks if an array contains the element "hello".
// Hint: Use google.
const array1 = ["hello", "world"];
const array2 = ["hi", "word"];
const containsHello = (wordArray) => {
    if (wordArray.includes("hello")) { // edited
        return true;
    } else {
        return false;
    }
}

console.log(containsHello(array1)); // Should return true
console.log(containsHello(array2)); // Should return false


// 1. Write a function that returns all numbers divisible by 3 between -1000 and 1000.
console.log("Bonus");
console.log("number 1");

const numbersDivisibleOnThree = () => {
    let three = "";
    for (i = -1000; i <= 1000; i++) {
        if (i % 3 === 0) {
            three += i + " "
        }
    }
    return three;
}
console.log(numbersDivisibleOnThree());


console.log("number 2");
// 2. Write a function that deletes all whitespace from a given string
let string = " hello world here is apollo18 ";

const whitespace = () => {
    return string.replace(/\s/g, "");
}
console.log(whitespace())

console.log("number 3");
/* Extra:
3. Write a function which reverses an array. Bonus: Do not use array.reverse() */
const myArray = [5, "two", 3, "today"];
const reverseArray = (arr) => {
    let resultArray = [];
    for (let i = arr.length - 1; i >= 0; i--) {
        resultArray.push(arr[i]);
    }
    return resultArray;
}
console.log(reverseArray(myArray))