# Klassenbuch
Ein Git basiertes soziales Netzwerk

## Aufgabe
Erstelle eine .md Seite die aussieht wie die Seite von Niels. (Nur mit eigenen Antworten).

1. Erstelle einen neuen branch mit deinem Namen.
2. In diesem Branch, erstelle eine neue .md Seite mit deinem Namen und deinen Antowrten.
3. Wenn du fertig bist, pushe deinen Branch und erstelle einen Merge Request. 
4. Bonus: Mach ein eigenes Repo und baue deine Seite in HTML anstelle von Markdown. 

## Tips
1. Male das Selbstportrait per Hand und Fotografier es mit der Handykamera ab oder finde irgendein Online Tool mit dem du es Digital malen kannst. 

2. Das Selbstportrait kommt in den /images Ordner. Finde selber raus wie du es einfügst. Tipp: https://github.com/adam-p/markdown-here/wiki/Markdown-Cheatsheet

2. Git Befehle die du brauchst:
git clone, git add, git commit, git pull, git push

3. Eine Liste an Emojis findest du hier: https://gist.github.com/rxaviers/7360908

4. Der Visual Studio Code Preview funktioniert nicht immer so gut mit git Markdown. Die Emojis werden z.B. nicht angezeigt.
