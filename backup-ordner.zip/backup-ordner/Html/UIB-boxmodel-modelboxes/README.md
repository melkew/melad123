# Basic CSS Exercises

## Exercise: CSS Grouping Selectors

**Instructions**:

1. Create a stylesheet and link it to the `index.html` file. 
2. Add styling to the `index.html` in order to make the page  resemble the mockup image below. 
3. Group the selectors where possible. 

![mockup-image](/image/mockup.png)