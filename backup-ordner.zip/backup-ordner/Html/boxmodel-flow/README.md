# They see me scrolling

**Instructions**: 
**Task 1**
* The sections with the class `esports-info` need to be styled. 
* First of all, give each section a set height and width.
* Give each section a border. 
* Set the size of the images. 
* Allow the user to scroll through the information on each section. 
![reference-task1](/images/reference-task1.png)

**Task 2**
* Make the image and paragraphs in the section with the class `esports-tournaments` appear side-by-side using float. 
![reference-task2](/images/reference-task2.png)

![reference-task](/images/reference.png)
