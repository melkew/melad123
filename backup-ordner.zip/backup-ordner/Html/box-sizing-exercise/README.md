# Box-Sizing-Exercise

**Instructions**:

Go to [Box Sizing Exercise](https://tl8b7x.axshare.com/home.html) and find the instructions for the tasks (german)
