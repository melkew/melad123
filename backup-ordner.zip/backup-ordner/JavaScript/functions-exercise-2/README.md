# Let's practice some more functions

### 1. Write a function that checks if a number is even or not. 
Example:

2 should return true

3 should return false

### 2. Write a function that accepts an array and returns all elements from that array in one string.
Example:

["apple", "orange", "banana"] should return "apple orange banana"

### 3. Write a function that checks if a number is positive.
Example:

3 should return true

-3 should return false

### 4. Write a function that accepts a string and returns the second letter
Example:

"abc" should return "b"

"hello World" should return "e"

### 5. Write a function that accepts a string and returns the second to last letter
Example:

"abc" should return "b"

"Hello World" should return "l"

### 6. Write a function that accepts an array and returns the last element.
Example:

[1, 3, 5] should return 5

["apple", "orange", "banana"] should return "banana"

### 7. Write a function that generates a random number between 20 and 30.

### 8. Write a function that accepts a string and converts it to lowercase
Example:

"Hello World" should return "hello world"
