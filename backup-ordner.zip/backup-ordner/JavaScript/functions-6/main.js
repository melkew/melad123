console.log("---1---");

// Create a function that takes a number (from 1 to 12) and returns its corresponding month name as a string. 
// For example, if you're given 3 as input, your function should return "March", because March is the 3rd month.

// Examples:

// monthName(3) ➞ "March"

// monthName(12) ➞ "December"

// monthName(6) ➞ "June"







const month = (number) => {
    let months = ["January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
    ]
    return months[number - 1];
}

console.log(month(1));



console.log("---2---");

// 2. Unlucky 13
// Given a sorted array of numbers, remove any numbers that are divisible by 13. Return the amended array.

// Examples:

// unlucky13([53, 182, 435, 591, 637]) ➞ [53, 435, 591] // 182 and 637 are divisible by 13.

// unlucky13([24, 316, 393, 458, 1279]) ➞ [24, 316, 393, 458, 1279] // No numbers in the array are divisible by 13.

// unlucky13([104, 351, 455, 806, 871]) ➞ [] // All numbers in the array are divisible by 13.





const checkUnlucky = (unlucky13) => {
    let newLucky = [];
    for (i = 0; i < unlucky13.length; i++) {
        if (unlucky13[i] % 13 !== 0) {
            newLucky.push(unlucky13[i])
        }
    }
    return newLucky
}
console.log(checkUnlucky([53, 182, 435, 591, 637]))
console.log(checkUnlucky([24, 316, 393, 458, 1279]))
console.log(checkUnlucky([104, 351, 455, 806, 871]))



console.log("---3---");

// 3. Filter out Strings from an Array
// Create a function which filters out strings from an array and returns a new array containing only integers.

// Examples:

// filterList([1, 2, 3, "x", "y", 10]) ➞ [1, 2, 3, 10]

// filterList([1, "a", 2, "b", 3, "c"]) ➞ [1, 2, 3]

// filterList([0, -32, "&@A", 64, "99", -128]) ➞ [0, -32, 64, -128]



const filter = (filterList) => {
    let number = [];
    for (i = 0; i < filterList.length; i++) {
        if (typeof (filterList[i]) == "number") {
            number.push(filterList[i]);
        }
    }
    return number;
}
console.log(filter([1, 2, 3, "x", "y", 10]));
console.log(filter([1, "a", 2, "b", 3, "c"]));
console.log(filter([0, -32, "&@A", 64, "99", -128]));



console.log("---4---");

// 4. Difference between Max and Min Numbers in an Array
// Create a function that takes an array and returns the difference between the biggest and smallest numbers.

// Examples:

// diffMaxMin([10, 4, 1, 4, -10, -50, 32, 21]) ➞ 82 // Smallest number is -50, biggest is 32.

// diffMaxMin([44, 32, 86, 19]) ➞ 67 // Smallest number is 19, biggest is 86.


const diffMaxMin = (MaxMin) => {
    let minNumber = Math.min.apply(Math, MaxMin);
    let maxNumber = Math.max.apply(Math, MaxMin);

    diffMaxMini = maxNumber - minNumber;
    return "the difference between min and max is " + diffMaxMini + " because the smallest is " + minNumber + " and the biggest is " + maxNumber;
}
console.log(diffMaxMin([10, 4, 1, 4, -10, -50, 32, 21]));
console.log(diffMaxMin([44, 32, 86, 19]));







let zaehler1 = function () {
    for (let x = 0; x < 10; x++) {
        return x;
    }
}

console.log(zaehler1())


let array1 = ["apple", "orange", "banana"];
let index = 2;
console.log(array1[index - 1]);



let backwardLoop = () => {
    for (let z = 0; z > -10; z--) {
        return `loop is at index ${z}`
    }
}
console.log(backwardLoop())





let aBetterBackwardLoop = () => {
let localString = "";
for (let y = 0; y> -10 ; y--){
     localString += " " + y;
    
}
return localString;
}
console.log(aBetterBackwardLoop());
