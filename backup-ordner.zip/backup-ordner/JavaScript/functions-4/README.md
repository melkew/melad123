# functions-4

Finish the functions in index.js
