console.log("Aufgabe 1:");
// 1. Print Exponential Values
// Write a function that accepts two numbers and validate that they are numbers.
// After that, the function should print y exponential values starting from x.

// For example if we have function(3, 5) The function should print 3 9 27 81 243. Prints 5 exponential values of 3.
// function(2, 8) The function prints 2 4 8 16 32 64 128 256. Prints 8 exponential values of 2.


let func = (a,b) =>{
    if(typeof a !=='number' || typeof b!== 'number' ){
        console.log("they are not a  number");
    }else{
             
            let exponentResult =1;
            let antwort ="";
            for (let i = 1; i <= b; i++){
                exponentResult = exponentResult * a;
                antwort = antwort + " " + exponentResult;
            }
            console.log(antwort);
        }
}
func(2,8)
func(3,5)

console.log("Aufgabe 2:");

let favoriteFruit = "apple";
let printFavoriteFruit =()=>{
   console.log(`my favorite fruit is ${favoriteFruit}`)
 } 
 printFavoriteFruit();

 console.log("Aufgabe 3:");


let exponent = (a, b) =>{

            let result =1;
           
            for (let i = 1; i <= b; i++){
                result = result * a;
            
            }
            console.log(result);
}
exponent(2,3);
// teil 3
// it is possible 

