# Fabulous Fonts

**Instructions**: 
* Choose a font from google fonts for all headings on the page. The font must be a `sans-serif` font.
* All elements nested in the `main` element should have a different `sans-serif` font. Provide a fallback in the font-stack. 
* The paragraph element with the class `code` should have a `monospace` font. Provide a fallback in the font-stack. 

![alt-text](/image/reference.png "Reference Image")