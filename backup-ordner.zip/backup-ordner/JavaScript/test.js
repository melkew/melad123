/*let x =3;
let y = 4;

console.log("3+4");

let x = 3;
let y = 4;

console.log(x);
// */
// const meinName = "Melad";
// // = is
//  console.log(meinName);
 

//  let ersteZahl = 4;
//  ersteZahl = ersteZahl+3;

//  console.log(ersteZahl);



const newElement = ()=>{
    var arr = ["banana" , "apple" , "mango"];
    var pos = 1 , n=0;
    var i;
  for (var i =3 ; i>=arr.length-1;i++){
      return arr.splice(pos, n);
  } 
}
console.log(arr(pos, n))