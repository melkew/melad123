
// console.log("Aufgabe 1:");
// let saml = 6450;
// let ticket = 15;
// let giwn = saml / ticket;

// console.log(giwn);

// console.log("Aufgabe 2:");

// let week = 500;
// let y = 12;
// let w = 4;
// let sam = y * w;
// let note5 = `${sam} dollar`

// console.log(note5);

// let durch = sam * week;
// console.log(durch);

// console.log("Aufgabe 3:");

// let Sam = 30;
// let teil = 17;
// let pro = 100;
// let precentage = (pro*teil) / Sam;
// // console.log(precentage)
// let an =  `${precentage} %`
// console.log(an);

// console.log("Aufgabe 4:");
//  let s = 4.75;
//  let pre = s * 4;
//  let note6 =`${pre} cm`
//  console.log(note6);


//  console.log("Aufgabe 5:");
// let s1 = 5;
// let s2 = 6;
// let s3 = 7;
// let traingle = s1 + s2 + s3 ;



// console.log(traingle)



//  console.log("Aufgabe 6:");
//  let right = 5;
//  let left = 5;
//  let area = right*left;
//  let not1 = `${area} cm` ;
//  console.log(not1);

//  console.log("Aufgabe 7:");

// let r1 = 5;
// let r2 = 6;
// let r3 = 7;
// let areaT = (r1 * r2 * r3 ) / 2;
// let note2 = `${areaT} cm²`
// console.log(note2);



console.log("Aufgabe 1:");
/* Q1. In one night, a movie theater sells tickets for 6450 dollars. 
Each ticket costs 15 dollars. How many tickets were sold? */

let verkaufteTickets = 6450/15;
console.log(verkaufteTickets);

console.log("Aufgabe 2:");
/* Q2. Sylvia's income is 500 dollars per week. 
How much does Sylvia makes every year? */

let wochenImJahr = 52; 
console.log(`Sylvia verdient ${500 * wochenImJahr} Dollar`);

console.log("Aufgabe 3:");
/* Q3. Calculate the percentage of 17/30.
 Expected output: number% */
// 1/2 = 0.5 = 50%
let prozentsatz = 17/30*100;
console.log(`${17/30*100}%`);

console.log("Aufgabe 4:");
/* Calculate the perimeter of a square. 
Assume each side is 4.75cm. */

let perimeter = 4.75*4;
console.log(`perimeter is ${perimeter} cm`);

console.log("Aufgabe 5:");
/* Calculate the perimeter of a triangle. 
Assume the length of the sides are 5cm, 6cm, 7cm.*/
let trianglePerimeter = 5 + 6 + 7;
console.log(`perimeter is ${trianglePerimeter} cm`);

console.log("Aufgabe 6:");
/*Calculate the area of a square. Each side is 5cm.*/
let squareArea = 5*5;
console.log(`Area of the square is ${squareArea}`);

console.log("Aufgabe 7:");
/* Calculate the area of a triangle. 
Assume the length of the sides are 5cm, 6cm, 7cm. */

let a = 5;
let b = 6;
let c = 7;
let p = (a+b+c) / 2;

let area = Math.sqrt(p*(p-a)*(p-b)*(p-c));

console.log(`Die Fläche des Dreiecks ist ${area} cm²`); 


let a = 5;
let b = 6;
let c = 7;
let p = (a+b+c) / 2;

let area = Math.sqrt(p*(p-a)*(p-b)*(p-c));

console.log(`Die Fläche des Dreiecks ist ${area} cm²`); 
console.log(`Die Fläche des Dreiecks ist ${area} cm²`);

console.log("Aufgabe 8");
/*
Q8. Calculate the volume of a cube. Length of each side is 9cm.
*/
console.log(`Das Volumen des Würfels ist ${9*9*9} cm³`);

console.log("Aufgabe 9");
/*
Q9. Calculate the three bills including tips:
€22.35 + 10% tip
€26.67 + 15% tip
€35.92 + 20% tip
*/
let bill1 = 22.35 * 1.1; // 22.35 + 22.35*0.1
let bill2 = 26.67 * 1.15;
let bill3 = 35.92 * 1.2;

console.log(`tip 1 ist ${bill1} Euro`);
console.log(`tip 2 ist ${bill2} Euro`);
console.log(`tip 3 ist ${bill3} Euro`);

console.log("Aufgabe 10");

/*
Q10. The number of hours Noemy worked over the last two weeks 
are 8, 6, 5, 9, 8, 2, 1, 8.5, 7, 4
What is Noemy's average hours worked per day?
*/

// Durchschnitt ist die Summe geteilt durch die Anzahl.

let summe = 8+6+5+9+8+2+1+8.5+7+4;
let durchSchnitt = summe / 10; 
console.log(`Noemy hat im Durchschnitt ${durchSchnitt} Stunden gearbeitet`);

console.log("Aufgabe 11");
/*
Q11. A math student scored 75, 70, 85, 90, 100 on the first 
five tests he took . After he took his sixth math test, 
the average is now 85. What did he score on the sixth test?
Expected output: Score in the sixth test: --.
(75+70+85+90+100+x)/6 = 85 
(75+70+85+90+100+x) = 85 * 6
x=85*6-75+70+85+90+100
*/

let ersteFuenfErgebnisse = 75+70+85+90+100;
let gesamtesErgebnis = 85 *6; 
let sechsterTest = gesamtesErgebnis - ersteFuenfErgebnisse;
console.log(`Ergebnis des letzten Tests ist ${sechsterTest}`);
