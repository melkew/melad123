# Normalize

**Instructions**: 
* Link `normalize.css` to the html file.

**Questions**: 
_Add your answers to this `README` file._

* What do you notice now that `normalize.css` is being used? Add your answer to this `README` file.

* Why is `normalize.css` useful? 

* What is the difference between normalize and css resets? 