# functions-5

Edit the functions given in index.js
