console.log("A 1:");


let i =1;

while(i<15){
    console.log(i)
    i=i+1
}


console.log("A 2:");


let a = 1;
let summe = 1;
while(a<20){
    console.log(a)
    summe= summe +a;
    console.log(summe)
    a=a+1
}


console.log("A 3:");

let b = 100;

do{
    console.log(b);
    b = b +1;
}while(b<=20)