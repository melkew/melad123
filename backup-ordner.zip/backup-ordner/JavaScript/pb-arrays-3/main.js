console.log("---Aufgabe1---");
// 1. The Greater Numbers. Create a function which accepts two arguments: the first argument being an array of numbers, 
// and the second argument being a number. 
// The function should return the elements of the array which are greater than the second argument.

// i.e.

// findGreatest([3, 4, 5], 4) ➞ 5

// findGreatest([10, 20, 30], 12) ➞ 20, 30

// findGreatest([0, 10, 3], 4) ➞ 10

const greater = (numArr, num) => {
    let array = [];
    for (i = 0; i < numArr.length; i++) {
        if (numArr[i] > num) {
            array.push(numArr[i])
        }

    }
    return array
}
console.log(greater([3, 4, 5], 4))
console.log(greater([10, 20, 30], 12))
console.log(greater([0, 10, 3], 4))


console.log("---Aufgabe2---");

// 2. For the longest word. Create a function to find the longest word in a given string.

// i.e. longestWord("this is a web development course") ➞ "development"


const findLongestWord = (str) => {
    let strSplit = str.split(" ");
    let longestWord = strSplit[0];
    for (i = 0; i < strSplit.length; i++) {
        if (strSplit[i].length > longestWord.length) {
            longestWord = strSplit[i];

        }
    }
    return longestWord
}

console.log(findLongestWord("this is a web development course"));


console.log("---Aufgabe3---");
// 3. Reverse. Create a function to reverse a number.

// i.e. reverse(34532) ➞ 23543
function reverse_a_number(n) {
    n = n + "";
    return n.split("").reverse().join("");
}
console.log(reverse_a_number(34532));


console.log("---Aufgabe4---");

// 4. AEIOU: Vowels. Create a function that takes a string in its parameters and counts the number of vowels (i.e. in English, "a, e, i, o, u") in the string.

// i.e. findVowels("this is a string") ➞ 4

const findVowels = (vowels) => {
    let array = ["a", "e", "i","o", "u" ]
    let count = 0;
    for (i = 0; i < vowels.length; i++) {
        if (vowels.includes(array[i])) {
            count += 1;
        }
    }
    return count
}
console.log(findVowels("this is a  string"));

let meinSatz = "Hallo hier ist ein satz";
let vowelCounter = (string) => {
    let vowels = ["a","e","i","o", "u"]
    let counter = 0;
    for(let i = 0; i<string.length; i++){
        // Hier geht er den string durch
        for(let j=0; j<vowels.length; j++){
            // Hier geht er den vowels array durch.
            if(vowels[j] === string[i]){
                counter += 1;
            }
        }
    }
    return counter; 
}
console.log(vowelCounter(meinSatz));