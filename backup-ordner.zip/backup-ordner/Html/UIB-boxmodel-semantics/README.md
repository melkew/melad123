# It's a matter of semantics

**Instructions**: 
* Look at the mock-up image below - determine which elements are being used on the page. 
* Create a very simple page using semantic elements. The page should offer some basic information about a topic that you're interested in. 
* Add basic styling to the page e.g. fonts, colors, borders etc. 

![mockup-image](/image/reference-image.png)