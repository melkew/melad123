# Build yourself a website

Your task is to build yourself a website. It needs to include at least 3 pages. Make it about your favorite musician, sports team, book, food or anything else you enjoy. 


### Requirements
1. Build it for mobile first.
2. It needs to look good on Mobile, Ipad and Desktop.
3. You need to include at least 3 pages. (For example: Home, About, Contact).
4. You need to include at least one google font. 
5. Host it via Github Pages.
6. Make it look nice.
