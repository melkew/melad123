console.log("Aufgabe 1:");
// 1. Multiply - Function Declaration
// Create a function that multiples a number by another number.

function multiply(a,b){
    let x = a*b;
    console.log(x)
}
multiply(4,5);

console.log("Aufgabe 2:");

// 2. Multiply - Function Declarations as Values
// Rework the syntax of the above function so that the function declaration is stored as a value.

let multiply2= function(a,b){
    let sub = a*b;
    console.log(sub)
}
multiply2(2,3)

console.log("Aufgabe 3:");

// 3. Multiply - Arrow Function
// Rework the syntax of the function declaration so that is uses the arrow function shorthand.

let func =(a,b) =>{
    console.log(a*b);
}
func (10,20);

console.log("Aufgabe 4:");

// 4. Declarations
// Create functions (using all three declarations) to check the remainder of division given two numbers.


function multiply3(a,b){
    let x = a%b;
    console.log(x)
}
multiply3(6,5);

let multiply4= function(a,b){
    let sub = a%b;
    console.log(sub)
}
multiply4(5,3)

let func2 =(a,b) =>{
    console.log(a%b);
}
func2 (33,20);

