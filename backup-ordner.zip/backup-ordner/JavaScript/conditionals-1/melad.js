console.log("A 1");

let x = 55; 
let y = 10;
if (((50 <= x) && (x <= 99)) || ((50 <= y) && (y <= 99))){
    console.log("true"); 
} // true

console.log("A 2");
let z = 75;

if (((50 <= x) && (x <= 99)) || ((50 <= z) && (z<= 99)) || ((50 <= y) && (y <= 99))){
    console.log("true"); 
}

console.log("A 3");

let a = 40;
let b = 50 ;
let c = 60 ;

if ((a > b) && (a > c)) {
    console.log("a ist größer als b und c")
} else if ((b > c) && (b > a)) {
    console.log("c ist größer als b und a ")
} else if ((c > a) && ( c > b)) {
    console.log("c ist die größte")
}

console.log("A 4");

let string = "Py";
let string1 = string.substring(0,2);

if (string === string1) {
    console.log("true")
} 

console.log("A 5");

let A = 30 ;
let B = 50 ;

if (50 < (A + B)<80) {
    console.log( "65");
} else {
    console.log ("80");
}

console.log("A 6");

let X = 50 ;
let Y = 42 ;

if(X+Y===8){
    console.log("die summe ist 8");
}
if (((Y - X ) === 8) || ((X - Y ) === 8)) {
    console.log("ist die differenz 8");
} 



console.log("A 7");

let p = 15 ;
let q = 30 ;

if (((p  === 15) || (q === 15)) || ((p+q)===15) ){
    console.log("true")
}


console.log("A 8");

let P = 48;
let Q = 22;

if (((P%7 === 0) || (Q%7===0)) || ((P%11 === 0) || (Q%11===0))) {
    console.log("true");
} else {
    console.log("false")

}

console.log("A 9");

let sum = P+Q;

if (P===Q) {
    console.log(sum * 3);
} else{
    console.log("false")
}


console.log("A 10");

let diff = Math.max(P - 19, 19- P); // oder kann man Math.abs schreibt und es ist immer positve wert

if (diff > 19){
    console.log(diff * 2)
} else{
    console.log(false)
}

console.log("A 11");

let age = 22;
let firstName = "Melad";

if (age < 13){
    console.log("Melad is a child");
} else if ((13 <= age) && (age< 20) ) {
    console.log("Melad is a teenager")
} else if ((20<= age)&& (age <30)) {
    console.log("Melad is a young adult")
} else {
    console.log("Melad is a adult")
}
