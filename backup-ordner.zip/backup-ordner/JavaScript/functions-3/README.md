# More Function Practice

Edit the index.js file and finish the functions. Good Luck!
