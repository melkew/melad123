console.log("Aufgabe 1: ");
/* Declare a variable named isDog. 
If true, print 'pat, pat' and if not, print 'find me a dog to pat!' */

let isDog = true;
console.log(isDog ? "pat, pat" : "find me a dog to pat");

console.log("Aufgabe 2:");
/* Declare a variable named speedCheck. 
The speedlimit is 50km/h. If your speed is above that, 
print 'you're going too fast!'. 
If speed is lower than 50km/h, 
print 'You're driving below the speed limit, Oma'. */

let speedCheck = 51;
console.log((speedCheck > 50) ? "you're going too fast" : "You're driving below the speedlimit, oma" );

console.log("Aufgabe 3:");
/* Declare a variable named age. If age is below 16, print 
"serve butter beer". Otherwise print "serve beer". */

let age = 16;
console.log((age < 16) ? "server butter beer" : "serve beer");

console.log("Aufgabe 4:");
/* Declare a variable named isStudent. 
If true, print "Ticket costs €5,00". If false, print "Ticket costs €12,00". */

let isStudent = false;
console.log((isStudent) ? "Ticket costs 5 Euro" : "ticket costs 12 Euro");

console.log("Aufgabe 5:");
/* Declare a variable named okMarie. 
Check if there is 'cake' - if so, print "Let them eat cake". 
If not, print "Oh, bother". */

let okMarie = "cake"; 
console.log((okMarie === "cake") ? "let them eat cake" : "oh bother");