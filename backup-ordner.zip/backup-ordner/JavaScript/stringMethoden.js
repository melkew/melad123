// let number = 10;
// let string = "10";
// let bool = true;

// let NumberAddition = Number + 1; //11
// let stringAddition = string + "1" //101

// // 47 /&§%"% " öjgnns = characters

// let name = "niels";
// let nzahlCharacters = name.length;
// console.log("niels".length);

// erstenBuchstaben = name [0]; 
// // the number means the number of the Characters
// console.log("nullter buchstabe ist:" + erstenBuchstaben);



// let name = "Melad";
// let großBuchstabe = name.toUpperCase();

// console.log(großBuchstabe);

// console.log(name.toUpperCase());

// let kleiBuchstaben = name.toLowerCase();
// console.log(kleiBuchstaben);

// // 0 1 2 3 4
// // M e l a d bis zu 3 und 3 gehört nicht dzu!
// // let teilString = name.substring(1,3);
// // console.log(teilString);

// let teilString = "el";
// console.log(name.includes(teilString));

// let Name = "       Melad             ";
// console.log(`mein name ist ${Name.trim()}!`)
//  // trim() nimmt die ganze leerzeichnen weg!



//  ** Dienstag

 let string = "   Das ist hier ein string  "
 let kleinbuchstaben = string.toLowerCase()
 let großBuchstaben = string.toUpperCase()
 let stringlaenge = string.length()
 let trimmedstring = tring.trim()
 let strin = "   Das ist hier ein string  "
 let kleinbuchstaben = string.toLowerCase()
 let großBuchstaben = string.toUpperCase()
 let stringlaenge = string.length()
 let trimmedstring = string.trim()
 let teilString = string.substring(9,12)
 let checkstring = string.includes(" ");

 let concatString = string + " noch ein string" 
 let nummerString = "1" + "1";
 let nummer = 1+1;
 let mischung = "1" + 1; // gleich wie 1 + "1"
 console.log(typeof(mischung));

 let intger = 100;   //
 let float = 3.14;  //gleich mit punkt was zu tun

 let result = parseInt() // es ist eine funktion
 let resultfloat = parsetfloat();



 let x = 12;
 console.log(x%3 === 0); //checkt ob eine zahl durch 3 teilbar ist.



//  new

let y = Math.ceil(30.111); //Rundet auf zur nächstgrößeren zahl
let x = Math.floor(30.111); //Rundet auf zur nächskleineren zahl
let a = Math.random()*8; //zufallszahl zwischen 0 und 1. Multiplizier sie um sie zu skalieren.
// zufkkszahl zwischen 2 und 10. Ganzenzählig.
let b = Math.floor(math.random()*8)+2;
// consol.long(b)
let c = Math.max(4,6,8,10,3);
// console.log(c)
let d = Math.min(2.4,7,-100.22,11);
// console.log(d)

