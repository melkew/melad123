# Language Placeholder

**Instructions**: 
* Center all headings. 
* Justify all paragraph elements. 
* Convert the direction of the Arabic text to be read right-to-left.

![alt-text](/image/reference.png "Reference Image")