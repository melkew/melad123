//Funktionen

// function summe(a, b){
//     console.log(a+b);
// }
// summe(1,2); //3


// let minus = (a, b) => {
//     console.log(a-b);
// }
//  minus(5,4);  //1



// let istGerade = (zahl) => {
//     if(zahl %2 === 0){
//         return true;
//     }else {
//         return false;
//     }
// }

// if (istGerade(6)){
//     console.log( "ist gerade");
// }


// function
function add(x, y){
    let summe = x+y;
    console.log(summe);
}
add(10, 10);

// function deklaration(Als variable)
let minus = function(a, b){
    let sub = a-b;
    console.log(sub)
}

let x = minus;
minus = "hallo welt!";
x(5,4);
console.log(minus);

let addition = function(a,b){
    let summe= a+b;
    console.log(summe)
}
addition(5,6)
addition(20,6)
addition(5,10)

// Arrow funktion
let divider = (a,b)=>{
    console.log(a/b)
}
divider(5,4)


// function test(a,b){
//     let y = a+b;
//     console.log(y);
// }
// console.log(y)


// Globaler Scop
let testFunktion = (a)=>{
    // lokaler scop
    let  z= 10;
    for(i=0; i<=10;i++){
        console.log(z)
    }
    console.log(a);
}
testFunktion(3);


let findExponents = (a, b)=>{
    // check ob a und b zahlen sind
    if(typeof a !== 'number' || typeof b !== 'number'){
        console.log("Fehler: keine Zahlen");
    }else {
        let exponentResult =1;
        let antwort ="";
        for (let i = 1; i <= b; i++){
            exponentResult = exponentResult * a;
            antwort = antwort + " " + exponentResult;
        }
        console.log(antwort);
    }
}
findExponents(2,8);


// Return statements
const addierer3 = (a, b) => {
    return a +b;
}

let addition1 = addierer3(3,4);
console.log(addition1); // console.log(addierer(2,2))  console.log(addierer("Hallo","welt"))

// wir schreiben funktion die chickt ob unser string "apple " ist oder nicht.

const checkApple =(fruit) => {
    if (fruit === "apple"){
        return true;
    }else {
        return false;
    }
}

console.log(checkApple);

var food ="apple";
if(checkApple(food)){
    console.log("schmeckt gut!");
}else {
    console.log("schmeckt nicht!");

}



// ------------------------
// Das heißt <<<<< array >>>>>
let arr =[1,2,3,4];
console.log(arr[2]);
return 