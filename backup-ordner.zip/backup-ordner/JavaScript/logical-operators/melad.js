console.log("Aufgabe 1:");

var a = true ;
var b = false;
console.log(a && b); // false
console.log(a || b); // true 
console.log(!(a && b)); // true


console.log("Aufgabe 2:");
var x = 2;
var y = 3;
var z = 4;

console.log("Aufgabe 3:");

console.log((x>z) && (x > y)); // false
console.log(!(x===y)); //true 
console.log((z < y)|| (x !== y)); //true 
console.log((x ===z) || (z > x)); // true 
console.log((x >= 10) && (y <= 10)); // false
console.log(((x*z)< 100) || ((x*y)> 100)); // true