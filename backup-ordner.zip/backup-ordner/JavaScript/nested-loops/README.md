# nested-loops

Finish the functions in index.js
