console.log("A 1")

let a = 3;
let b = "3";
console.log(a == b); // true weil hier ein typ konvertiert.
console.log(a === b);// false weil hier nichts konvertiert.
//strict . less errors.
console.log(a = b); // 3 hat string b in the variable a gestickt.
//console.log("3" = 3); // error 
 
 
console.log("A 2");

let x = true;
console.log(x ? !"true" : "false");

console.log("A 3");

let firstName, givenName;

firstName = 'Stacey';
let name = givenName || firstName || 'John'; 

console.log(name); // Stacey. 