# Programming Basics: Comparison Operators

These exercises are aimed at making you familiar with the comparison operators. **Print all your checks to the console.**

0. Declare two variables "x" and "y". Assign a value of 20 to x. Assign a value of 30 to y. 

1. Check whether x and y are equal. 

2. Check whether x and y are *not* equal. 

3. Check whether x is greater than y. 

4. Check whether x is less than or equal to y. 

5. Check whether y is greater than x. 

6. Declare another variable "z" and give it a value of 5. Multiply z and x, and check whether this result is greater than z added to y. 

7. Subtract z from x and check whether this result is less than y divided by z. 

8. Check whether z, x and y are equal. 

9. Check whether the remainder of x divided by z and the remainder of y divided by z are equal.  

10. Check whether z added to x is greater than y minus z. If it is not, find an operator which will give a result of true.

11. BONUS CHALLENGE: Try increasing script readability by adding question headings to your output before each result.
