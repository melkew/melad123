console.log("1. The Fortune Teller");
/* Write a function named tellFortune that: 
takes 4 arguments: number of children, partner's 
name, geographic location, job title. outputs your 
fortune to the screen like so: "You will be a X 
in Y, and married to Z with N kids." 
Call that function 3 times with 3 different 
values for the arguments.*/

function tellFortune(numberOfChildren, partnerName, location, job){
    return `You will be a ${job} in ${location}, and married to ${partnerName} with ${numberOfChildren} kids.`;
}

let x = tellFortune(5, "Susi", "Berlin", "Coder");
console.log(x);

console.log("Aufgabe 2");

function calculateDogAge(dogAge){
    let humanAge = dogAge * 7;
    console.log(`Your doggie is ${humanAge} years old in dog years!`)
}

calculateDogAge(3);
calculateDogAge(7);
calculateDogAge(10);

function calculateHumanAge(humanAge) {
    let age = humanAge / 7;
    console.log(`Your doggie is ${age} years old in calendar years!`);
}

calculateHumanAge(70);