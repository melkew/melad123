console.log("Aufgabe 1:");

let a = Math.min(-1, 4);
let b = Math.max(-1, 4);

console.log(a);
console.log(b);

console.log("Aufgabe 2:");

let x = Math.ceil(3321.32321);
let x1 = Math.ceil(326.76);
let x2 = Math.ceil(76788.7);
let x3 = Math.ceil(-9.78);
let x4 = Math.ceil(43.342);

console.log(x);
console.log(x1);
console.log(x2);
console.log(x3);
console.log(x4);

let y = Math.floor(3321.32321);
let y1 = Math.floor(326.76);
let y2 = Math.floor(76788.7);
let y3 = Math.floor(-9.78);
let y4 = Math.floor(28.329);

console.log(y);
console.log(y1);
console.log(y2);
console.log(y3);
console.log(y4);

console.log("Aufgabe 3:");

let c = Math.ceil(Math.random()*6);  // ceil ist wichtig
console.log(c);     

// let random = Math.random(); // Eine Floating Point Zahl zwischen 0 und 1.
// let randomMal5 = random * 6; // Gib uns 6 Verschiedene Zahlen. Zwischen 0. und 6.
// let aufgerundet = Math.ceil(randomMal5); // Runde diese Zahlen auf. Zwischen 1 und 6.
// console.log(aufgerundet)