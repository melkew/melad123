console.log("A 1:");
 let color = "red";
switch(color){
    case "blue" : 
        console.log("the color is blue");
        break;
    case "red":
        console.log("the color is red");
        break;
    case "yellow":
        console.log("the color is yellow");    
    default:
        console.log("die Farbe ist weder blue, noch red");

}

console.log("A 2:");

let note = "4"


switch(note){
    case "5" : 
        console.log(" really bad");
        break;
    case "4":
        console.log("bad");
        break;
    case "3":
        console.log("not really good");
        break;
    default:
        console.log("es ist nicht bestanden");

}

console.log("A 3:");
let fruit= "apple"

switch(fruit){
    case "banana" : 
        console.log("fruit ist apple");
        break;
    case "apple":
        console.log("fruit ist banana");
        break;
    default:
        console.log("fruit ist weder apple, noch banana");

}


console.log("A 4:");

let number = 30;

if(number < 30){
        console.log("Still a long way to go")
    }
    else if ((30 <= number) && (number<50)){
        console.log( "Slowly getting there")
    }
    else if ((51<number)&&(number<80)){
        console.log("You can do it!");
    }
    else if ((81<number) && (number<99)){
        console.log("This is the last push!");
    }
       
    else if (number === 100) {
        console.log("You're there. Well done!");
    }  
    else {
        console.log("kann nicht sein");
}


console.log("A 5:");

console.log("switch is usually more compact than lots of nested if else and therefore, more readable")