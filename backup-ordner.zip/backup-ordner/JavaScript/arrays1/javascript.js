let myArray = ["blau","rot","grün","gelb","rosa"];

console.log(myArray);
console.log(myArray[1]);
myArray [4] = "fourth element";
console.log(myArray);