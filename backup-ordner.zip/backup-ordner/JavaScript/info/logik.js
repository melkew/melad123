// var x = false;
// var y = true ;

// console.log(x && y);

//ist x und y das selbe? und ist diese zahl nicht 11
y = 10;
let x =10;
console.log((x ===y)&& (y === 11));
 // ist gleich weil ! tret die ganze satz um
 console.log((x==y)&& !(y===11));


 // ist x und y das selbe? oder ist diese zahl größer als 11

 console.log((x==y)|| (y>11));

///////////////////////////
 let x = "abc";
 x =null;
 console.log(x);

 ////////////////////////////
 let x = 10;
 let y = "10";

 console.log(x == y ); //true wird ein typ konvertiert
 console.log(x === y); //false wird nichts konvertiert

 //////////////////////////

 let x;
 let y = x || "10";
 console.log(y); // 10

 ////////////////////////////

 //fläsche eines Quadrats 

 let breit = 10;
 let hoehe = 11;

 let flaesche = briet * hoehe;
 
 /////////////////////


if (true) {
    Console.log("HELLO WORLD");
} // HELLO WORLD
////
x = 10;
y = 11;

if  ((x === y) || (y < 100)) {
    Console.log("HELLO WORLD");
} // hello world 

//////

let a = (x === y) ? "x ist y" : "x ist nicht y";

if ( x === y) {
    console.log("x ist y");
    // let a = "x ist y";
} else {
    console.log( "x ist nicht y");
    // let a = "x ist nicht y";
}


///////////////////////
x = 10;
y = 10;

if ( x === y) {
    console.log("x ist y");
    // let a = "x ist y";
 }else if (x === y){
    console.log("x ist y");
 }
 else {
    console.log( "x ist nicht y");
    // let a = "x ist nicht y";
}


///////////////////////////////
let x = 10;

switch(x){
    case 10 : // inhalt
        console.log("x ist 10");
        break;
    case 1:
        console.log("x ist 1");
        break;
    default:
        console.log("x ist weder 10, noch 1");

}

if(x === 10){
    console.log("x ist 10");
} else if (x===1){
    console.log("x ist 1");
}
else{
    console.log("x ist weder 10, noch 1");
}
// sind gleich
/////////////////////////////////////////
let fruit= "apple";

switch(x){
    case "banana" : // inhalt
        console.log("fruit ist apple");
        break;
    case "apple":
        console.log("fruit ist banana");
        break;
    default:
        console.log("fruit ist weder apple, noch banana");

}


/////////////////////////////////////

//while

//DRY dont repeat yourself.
//wir wollen alle zahlen zwischen 1 und 10

// while(//solange diese kondition true ist){
// Führe das hier }

let i = 1;
while(i<=10){
    console.log(i);
    i = i+1;
}

let i = 1;
while(i<=20){
    console.log(i);
    i = i *1;
}
/////////////////
// let i = 21 
do{
    console.log(i);
    i = i +1;
}while(i<=20)

/////////////////
// Wir alle Zahlen zwischen 20 und 30 addieren
// 20 + 21 + 22 + 23... 30
let i = 20;
let summe = 0;
// Während i kleiner oder gleich 30 ist
while (i<=30) {
    //Gebe i aus
    console.log(i);
    //Setze die summe als sich selbst + i
    summe = summe + i; 
    //Gebe die Summe aus
    console.log(summe);
    //Setze i als sich selbst + 1
    i++;
}

// Alle zahlen zwischen 1 und 5. Der test passiert erst nach der Schleife.
// Sie wird mindestens ein mal ausgeführt.
do {
    console.log(i);
    i = i + 1;
} while(i<=5)

/////////////////////////////

