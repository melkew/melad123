# UI-Basics-Content-Classes&IDs

# How about ID'S?

**Instructions**:

-   Modify either the classes or Id's in the HTML file and add or change the corresponding classes and Id's in the CSS file that you have for this exercise to make sure the text of the whole page is only in color blue.

![alt-text](reference-image.png "Reference Image")

**Bonus**:

-   Separate the p tags in different DIVs.
-   Give either an ID or a class to each DIV.
-   Add a background color to each DIV.
