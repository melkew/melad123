console.log("---1---");
// sumOfNumbers. Create a program that adds up the numbers in an array (of at least 3 numbers). 
// Bonus: Print to screen both the sum and the product of these numbers.

let numbers = [10, 15, 50, 40]
let sum = 0;
let p = 1;
for (var i = 0; i < numbers.length; i++) {
    sum += numbers[i];
    p *= numbers[i];
}
console.log(sum);
console.log(p);

console.log("---2---");

// Hello Frien Create an array filled with your friends' and family's names. 
// Loop over the array and greet each friend e.g. Hello Maria! Hello Mike! etc.
// Bonus: Print the indexes of each item in the array. Expected output example: 
// Mike is at index 1 of my friends array.

let names = ["Gael", "Kinan", "Majd", "Melad", "Niels"];

names.forEach(element => console.log("Hello" + " " + element));
// names.forEach(element => console.log(element + " is at index "+ names.indexOf[i] +" of my friends array" ));


// for(let i=0; i<names.length ;i++){
//     console.log("hello" + names(i));
// }

console.log("---3---");

// City Names. Create an array of city names. 
// Loop through the array and add the city names to a string.
//  Example of expected output: "Berlin, Paris, Prague, Rome".

const citiesNames = ["Berlin", "Paris", "Prague", "Rome"];
let newCity = "";
for (i = 0; i < citiesNames.length; i++) {
    newCity += citiesNames[i] + ", ";
}
console.log(newCity)


console.log("---4---");

// Odds and Evens. Create a program that changes a given array by 
// adding 1 to each odd integer and subtracting 1 from each even integer. Examples:

// [3, 5, 2, 4] ➞ expected output: [4, 6, 1, 3]
// [6, 9, 10, 20] ➞ expected output: [5, 10, 9, 19]



const summ = () => {
    const number = [3, 5, 2, 4];
    const numberForOne = [];
    for (i = 0; i <= number.length - 1; i++) {
        if (number[i] % 2 === 0) {
            numberForOne.push(number[i] - 1);
        } else {

            numberForOne.push(number[i] + 1);
        }
    }
    return numberForOne
}
console.log(summ([3, 5, 2, 4]));


console.log("---5---");

// Capitalize. Create a program that capitalises the first letter of each element in an array of names. Examples:
// ["matt", "sara", "lara"] ➞ ["Matt", "Sara", "Lara"]

// ["samuel", "MARIA", "luke", "mary"] ➞ ["Samuel", "Maria", "Luke", "Mary"]

// ["Cynthia", "Karen", "Jane", "Carrie"] ➞ ["Cynthia", "Karen", "Jane", "Carrie"]

// Note: Keep names in the same order and make sure that only the first lesson of the name is capitalised (See "Maria" in the second above example).




function convertCase(str) {
    let first = "";
    let newstr = [];
    for (i = 0; i < str.length; i++) {
        var lower = str[i].toLowerCase();
        first = lower[0].toUpperCase() + lower.substring(1);
        newstr.push(first);
    }
    return newstr
}
console.log(convertCase(["matt", "sara", "lara"]));


console.log("---6---");


// Repeat it. Create a program with two variables: "item" and "times". 
// Create a program that repeats the "item" as many times as specified by "times". 
// The first variable ("item") is the item that needs repeating while the second argument ("times")
//  is the number of times the item is to be repeated. Print the result in an array.
// Example: ("example", 3) ➞ ["example", "example", "example"]


const repeat = (item, time) => {
    let array = []
    for (i = 0; i < time; i++) {
        array.push(item)
    }
    return array
}
console.log(repeat('melad ', 3))


console.log("---Bonuses1---");

// Factors. A factor chain is an array where each previous element is a factor of the next consecutive element.
//  The following is a factor chain: [3, 6, 12, 36]

// 3 is a factor of 6 (3 * 2 = 6)
// 6 is a factor of 12 (6 * 2 = 12)
// 12 is a factor of 36 (12 * 3 = 36)

const checkFactor = (factor) => {
    let result = "";
    for (i = 0; i < factor.length - 1; i++) {
        result = `${factor[i]} is a factor of ${factor[i+1]} (${factor[i]} * ${(factor[i+1]/factor[i])} = ${(factor[i])* (factor[i+1]/factor[i])})`
        console.log(result)
    }
}

checkFactor([3, 6, 12, 36])

console.log("---Bonuses2---");

// Create a program that determines whether or not a given array is a factor chain.

// Examples
// [1, 2, 4, 8, 16, 32] ➞ true
// [1, 1, 1, 1, 1, 1] ➞ true
// [2, 4, 6, 7, 12] ➞ false
// [10, 1] ➞ false


// const check =(factors,num)=>{
//     for(i=0; i<=factors.length; i++){
//         if(num%factors[i]===0){
//             return true;
//         }else{
//             return false;
//         }
//     }
// }
// console.log(check([1, 2, 4, 8, 16, 32],32));
// console.log(check([1, 1, 1, 1, 1, 1],1));
// console.log(check([2, 4, 6, 7, 12],1 ));
// console.log(check([10, 1],1));



const check = (factors) => {
    for (i = 1; i < factors.length; i++) {
        if (factors[i] % factors[i - 1] !== 0) {
            return false;
        }
    }
    return true;
}
console.log(check([1, 2, 4, 8, 16, 32]));
console.log(check([1, 1, 1, 1, 1, 1]));
console.log(check([2, 4, 6, 7, 12]));
console.log(check([10, 1]));


console.log("---Bonuses3---");

// No Duplicates! A set is a collection of unique items. A set can be formed from an array by removing all duplicate items. 
// Create a program which transforms an array into a set of unique values. See the examples below. Example:

// [1, 4, 4, 7, 7, 7] ➞ [1, 4, 7]

// [1, 6, 6, 9, 9] ➞ [1, 6, 9]

// [2, 2, 2, 2, 2, 2] ➞ [2]

// [5, 10, 15, 20, 25] ➞ [5, 10, 15, 20, 25]

const duplicates = (array) => {
    let newArr = [];
    for (let i = 0; i < array.length; i++) {
        if (!newArr.includes(array[i])) {
            newArr.push(array[i]);
        }
    }
    return newArr;
}
console.log(duplicates([1, 4, 4, 7, 7, 7])); //[1, 4, 7]
console.log(duplicates([1, 6, 6, 9, 9])); //[1, 6, 9]
console.log(duplicates([2, 2, 2, 2, 2, 2])); //[2]
console.log(duplicates([5, 10, 15, 20, 25])); //[5, 10, 15, 20, 25]