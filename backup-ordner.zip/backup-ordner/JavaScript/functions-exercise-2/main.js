
/* Write a function that checks if a number is even or not.*/
function oddOrEven(x) {
    if (x % 2 === 0) {
        return true;
    } else {
        return false; 
    }
  }
  console.log(oddOrEven(1)); // even
  console.log(oddOrEven(5)); // odd




/*Write a function that accepts an array and returns 
all elements from that array in one string. */

// [2, 3, 4]  -> "2 3 4"

function arrayZuString(arr){
    let result = "";
    for(let i = 0; i < arr.length; i++){
        result = result + " " + arr[i];
    }
    return result;
}
let fruit = ["apple", "orange", "banana"];
// console.log(arrayZuString(fruit));

console.log("Aufgabe 3");

/*  Write a function that checks if a number is positive. */

function isPositive(zahl){
    if(zahl >= 0) {
        return true;
    } else {
        return false;
    }
}

console.log(isPositive(3)); // True
console.log(isPositive(-1)); // false
console.log(isPositive(0)); // true

console.log("Aufgabe 4");
/* Write a function that accepts a string and 
returns the second letter. */

function secondLetter(word){
    return word[1];
}

let word = "hallo welt";

console.log(secondLetter(word));

console.log("Aufgabe 5");
/* Write a function that accepts a string and returns 
the second to last letter. */

function secondToLastLetter(string){
    console.log(string[string.length-2]);
}

secondToLastLetter("Hallo Welt"); 


console.log("aufgabe 6: ");


//Write a function that accepts an array and returns the last element.
function lastElement(last){
    return last[2];
}
// function lastElement(arr){
//     console.log(arr.length);
// }
console.log(lastElement([1,3,5]));
console.log(lastElement(["apple", "orange", "banana"]));

console.log("Aufgabe 7:");

//Write a function that generates a random number between 20 and 30.
/*
let randomNum = (min,max)=>{
	return Math.floor(Math.random()* (max - min + 1) )+ min;
}
console.log(randomNum(20,30));
    */
let nielsRandom = () => {
    console.log(Math.random()*10 +20);
}
nielsRandom();

console.log("Aufgabe 8:");

//Write a function that accepts a string and converts it to lowercase.

let stringFunktion = (string) => {
    if (typeof string==='string'){
        return string.toLowerCase()
    } else {
        return "this element isn`t element ";
    }
}
console.log(stringFunktion("Hallo Welt"));