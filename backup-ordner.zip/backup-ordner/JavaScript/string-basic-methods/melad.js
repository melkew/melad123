
console.log("Aufgabe 1:");

let satz =  "I can walk in the park all day!";
console.log(satz.substring(18,22));

console.log("Aufgabe 2:");

let hello = "Hello World";
console.log(hello.toUpperCase(hello));


console.log("Aufgabe 3:");

let earthling = "Hello Earthling";
console.log(earthling.toLowerCase(earthling));

console.log("Aufgabe 4:");

let jave = "JavaScript";
console.log(jave.substring(3,6));

console.log("Aufgabe 5:");

let nice = "nice shoes";
let teilstring1 = "I";
let teilstring2 = "n";
console.log(nice.includes(teilstring1));
console.log(nice.includes(teilstring2))

// console.log(nice.includes(`l`))
// console.log(nice.includes(`n`))

console.log("Aufgabe 6:");

let New = "Apple"
console.log(New.substring(0,1)+New+New.substring(0,1));

console.log("Aufgabe 7:");

let New1 = "geund";
console.log(New1.substring(2,5)+New1+New1.substring(2,5));

console.log("Aufgabe 8:");

let variable = "Oi, oi, oi";
console.log(variable.toUpperCase());
let check = "oi";
console.log(variable.includes(check));

console.log("Aufgabe 9:");

let variable1 = "BoogieWoogie";
console.log(variable1.substring(11, 12) + variable1.substring(1, 11) + variable1.substring(0, 1));



console.log("Aufgabe 10:");

let name = "melad";
let birthday = "august"
let city = "berlin";
console.log(`my name is ${name} , i born in ${birthday} and  live in ${city}`);

console.log("Aufgabe 11:");

let varTen = "the quick brown fox";
console.log(varTen.charAt(0).toUpperCase() + varTen.slice(1));