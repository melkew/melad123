console.log("Aufgabe 1");
let myArray = ["apple", "orange", "banana", "kiwi", "ananas"];
console.log(myArray);

console.log("Aufgabe 2");
let thirdElement = myArray[3];
console.log(thirdElement);

console.log("Aufgabe 3");
myArray[3] = "fourth element";
console.log(myArray);

