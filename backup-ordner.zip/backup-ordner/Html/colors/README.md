# Coloring Book

**Instructions**: 
* Style each of the headings with the colors described in the heading.
* Once you're finished, add alpha to each of the headings using `rgba`. 
* Then select all the paragraphs and add a hex color.

![task1](/images/task1.png)
![task2-and-3](/images/task2-3.png)