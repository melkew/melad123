# Basic HTML Exercises

## Exercise: Bring Me A Tree

**Instructions**:

1. Use google to find an image of a tree, display the image in the HTML.
2. Add a fallback text that says "A tree , for you!".
3. Make sure you find the size of the image, and add the image to the page with a width of
 300 pixels without distorting or stretching the image.

